﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482221022
{
    public partial class frmContato : Form
    {
        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsCidade = new DataSet();
        private DataSet dsContato = new DataSet();
        public frmContato()
        {
            InitializeComponent();
        }

        private void FrmContato_Load(object sender, EventArgs e)
        {
            try
            {
                Contato Com = new Contato();
                dsContato.Tables.Add(Com.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContatos.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;

                txtIdContato.DataBindings.Add("TEXT", bnContato, "id_Contato");
                txtNomeContato.DataBindings.Add("TEXT", bnContato, "nome_Contato");
                txtEndContato.DataBindings.Add("TEXT", bnContato, "end_Contato");
                txtTelefoneContato.DataBindings.Add("TEXT", bnContato, "cel_Contato");
                txtEmailContato.DataBindings.Add("TEXT", bnContato, "email_Contato");
                dtpDataContato.DataBindings.Add("TEXT", bnContato, "dtCadastro_contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                cbxCidadeContato.DataSource = dsCidade.Tables["Cidade"];
                cbxCidadeContato.DisplayMember = "nome_cidade";
                cbxCidadeContato.ValueMember = "id_cidade";
                cbxCidadeContato.DataBindings.Add("SelectedValue", bnContato,"cidade_id_cidade");


            }

            catch (Exception)
            {
                MessageBox.Show("Erro ao listar cidades!");
            }
        }

        private void BtnNovo_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }

            bnContato.AddNew();

            txtNomeContato.Enabled = true;
            txtEmailContato.Enabled = true;
            txtEndContato.Enabled = true;
            cbxCidadeContato.Enabled = true;
            txtTelefoneContato.Enabled = true;
            dtpDataContato.Enabled = true;


            btnNovo.Enabled = false;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = true;
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNomeContato.Text == "" || txtNomeContato.Text.Length < 3)
            {
                MessageBox.Show("Nome do Contato inválido");
            }
            else if (txtEndContato.Text == "" || txtEndContato.Text.Length < 3)
            {
                MessageBox.Show("Endereço do contato inválido");
            }
            else if (cbxCidadeContato.Text == "" || cbxCidadeContato.Text.Length < 2)
            {
                MessageBox.Show("Cidade do Contato inválida");
            }
            else if (txtTelefoneContato.Text == "" || txtTelefoneContato.Text.Length < 3)
            {
                MessageBox.Show("Telefone do Contato inválido");
            }
            else if (txtEmailContato.Text == "" || txtEmailContato.Text.Length < 8)
            {
                MessageBox.Show("E-mail do Contato inválido");
            }
            else if (dtpDataContato.Text == "" || dtpDataContato.Text.Length < 8)
            {
                MessageBox.Show("Data inválida");
            }
            else
            {
                Contato RegCon = new Contato();
           
                RegCon.Nomecontato = txtNomeContato.Text;
                RegCon.Endcontato = txtEndContato.Text;
                RegCon.Cidadeidcidade = Convert.ToInt32(cbxCidadeContato.SelectedValue.ToString());
                RegCon.Celcontato = txtTelefoneContato.Text.ToString();
                RegCon.Emailcontato = txtEmailContato.Text.ToString();
                RegCon.DtCadastrocontato = Convert.ToDateTime(dtpDataContato.Text);
                    
                if (bInclusao)
                {
                    if (RegCon.Salvar() > 0)
                    {
                        MessageBox.Show("Contato adicionado com sucesso!", "SUCESSO");

                        txtNomeContato.Enabled = false;
                        txtIdContato.Enabled = false;
                        txtEmailContato.Enabled = false;
                        txtEndContato.Enabled = false;
                        txtTelefoneContato.Enabled = false;
                        cbxCidadeContato.Enabled = false;
                        dtpDataContato.Enabled = false;

                        btnNovo.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCon.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Contato!", "ERRO");
                    }
                }
                else
                {
                    RegCon.IdContato = Convert.ToInt32(txtIdContato.Text);
                    if (RegCon.Alterar() > 0)
                    {
                        MessageBox.Show("Contato alterado com sucesso!");

                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCon.Listar());

                        txtNomeContato.Enabled = false;
                        txtIdContato.Enabled = false;
                        txtEmailContato.Enabled = false;
                        txtEndContato.Enabled = false;
                        txtTelefoneContato.Enabled = false;
                        cbxCidadeContato.Enabled = false;
                        dtpDataContato.Enabled = false;


                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCon.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar Contato!");
                    }
                }

            }
        }

        private void BtnAlterar_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            txtNomeContato.Enabled = true;
            txtIdContato.Enabled = false;
            txtEndContato.Enabled = true;
            txtEmailContato.Enabled = true;
            txtTelefoneContato.Enabled = true;
            cbxCidadeContato.Enabled = true;
            dtpDataContato.Enabled = true;
            txtNomeContato.Focus();

            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Contato RegCon = new Contato();
                RegCon.IdContato = Convert.ToInt16(txtIdContato.Text);
                if (RegCon.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluído com sucesso!");
                    Contato R = new Contato();
                    dsContato.Tables.Clear();
                    dsContato.Tables.Add(R.Listar());
                    bnContato.DataSource = dsContato.Tables["Contato"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Contato!");
                }

            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();

            txtNomeContato.Enabled = false;
            txtIdContato.Enabled = false;
            txtEmailContato.Enabled = false;
            txtEndContato.Enabled = false;
            txtTelefoneContato.Enabled = false;
            cbxCidadeContato.Enabled = false;
            dtpDataContato.Enabled = false;

            btnSalvar.Enabled = false;
            txtNomeContato.Enabled = false;
            txtIdContato.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
